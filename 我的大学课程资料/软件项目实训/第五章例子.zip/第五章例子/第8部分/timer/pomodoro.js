class Pomodoro {
  constructor(audio) {
    this.states = [
      { from: 'stopped', to: 'timing', action: 'start' },
      { from: 'stopped', to: 'editing', action: 'edit' },
      { from: 'timing', to: 'paused', action: 'pause' },
      { from: 'timing', to: 'stopped', action: 'stop' },
      { from: 'paused', to: 'timing', action: 'start' },
      { from: 'paused', to: 'stopped', action: 'stop' },
      { from: 'paused', to: 'editing', action: 'edit' },
      { from: 'editing', to: 'stopped', action: 'save' },
      { from: 'editing', to: '', action: 'cancel' },
    ];

    this.currentState = 'stopped';
    this.totalSeconds = 25 * 60;
    this.remainSeconds = this.totalSeconds;
    this.timer = null;
    this.audio = audio;
  }

  get actions() {
    return this.states.filter(_ => _.from === this.currentState)
      .map((value) => value.action);
  }

  start() {
    this.currentState = 'timing';
    this.startTimer();
  }
  stop() {
    this.currentState = 'stopped';
    this.remainSeconds = this.totalSeconds;
    this.stopTimer();
    this.audio.load();
  }
  pause() {
    this.currentState = 'paused';
    this.stopTimer();
    this.audio.pause();
  }
  edit() {
    this.currentState = 'editing';
  }
  save(seconds) {
    this.currentState = 'stopped';
    this.totalSeconds = seconds;
    this.remainSeconds = seconds;
  }
  cancel() {
    this.currentState = this.totalSeconds === this.remainSeconds ? 'stopped' : 'paused';
  }

  startTimer() {
    this.timer = setInterval(() => this.countdown(), 1000);
  }
  stopTimer() {
    clearInterval(this.timer);
    this.timer = null;
  }
  countdown() {
    if (this.remainSeconds == 0) {
      this.stopTimer();
      this.audio.play();
      return;
    }
    this.remainSeconds-=1;
    console.log(this.remainSeconds);
  }
}