//slideimages����Ϊ�任��ͼ
var slideimages=new Array();
slideimages[0]="images/ad-01.jpg";
slideimages[1]="images/ad-02.jpg";
slideimages[2]="images/ad-03.jpg";
slideimages[3]="images/ad-04.jpg";
slideimages[4]="images/ad-05.jpg";
//slidetext�����б���ͼƬ�·���Ҫ��ʾ������
var slidetext=new Array();
slidetext[0]="ͼ01";
slidetext[1]="ͼ02";
slidetext[2]="ͼ03";
slidetext[3]="ͼ04";
slidetext[4]="ͼ05";
//slidetext����Ϊ���ÿ����ͼ����ת��URL
var slidelinks=new Array();
slidelinks[0]="http://www.njupt.edu.cn";
slidelinks[1]="http://www.njupt.edu.cn";
slidelinks[2]="http://www.njupt.edu.cn";
slidelinks[3]="http://www.njupt.edu.cn";
slidelinks[4]="http://www.njupt.edu.cn";
//����ͼ��ʼ���ݣ���start
var slidespeed=3000
var slidesanjiaoimages=new Array("images/bian2.gif","images/bian1.gif");
var slidesanjiaoimagesname=new Array("tu1","tu2","tu3","tu4","tu5");
var filterArray=new Array();
filterArray[0]="progid:DXImageTransform.Microsoft.Pixelate (enabled=false,duration=2,maxSquare=25 )";
filterArray[1]="progid:DXImageTransform.Microsoft.Stretch (duration=1,stretchStyle=PUSH)";
filterArray[2]="progid:DXImageTransform.Microsoft.Stretch(duration=1)";
filterArray[3]="progid:DXImageTransform.Microsoft.Slide(bands=8, duration=1)";
filterArray[4]="progid:DXImageTransform.Microsoft.Fade ( duration=1,overlap=0.25 )";
var imageholder=new Array()
var ie55=window.createPopup
for(i=0;i<slideimages.length;i++){
  imageholder[i]=new Image()
  imageholder[i].src=slideimages[i]
}

function tu_ove(){
  clearTimeout(setID)
}
function ou(){
  slideit()
}
var whichlink=0
var whichimage=0
function gotoshow(){
  window.open(slidelinks[whichlink]);
}
function slideit(){
  document.images.slide.style.filter=filterArray[whichimage];
  pixeldelay=(ie55)? (document.images.slide.filters[0].duration*1000) : 0
  if (!document.images) return
  if (ie55) {
    document.images.slide.filters[0].apply();
    document.images.slide.filters[0].play();
  }
  document.images.slide.src=imageholder[whichimage].src
  document.getElementById("textslide").innerText=slidetext[whichimage];
  document.getElementById("tu1").src=slidesanjiaoimages[0];
  document.getElementById("tu2").src=slidesanjiaoimages[0];
  document.getElementById("tu3").src=slidesanjiaoimages[0];
  document.getElementById("tu4").src=slidesanjiaoimages[0];
  document.getElementById("tu5").src=slidesanjiaoimages[0];
  document.getElementById(slidesanjiaoimagesname[whichimage]).src=slidesanjiaoimages[1];
  if(ie55)
    document.images.slide.filters[0].play()
  whichlink=whichimage
  whichimage=(whichimage<slideimages.length-1)? whichimage+1:0
  setID=setTimeout("slideit()",slidespeed+pixeldelay)
}
slideit()
function ove(n){
  clearTimeout(setID)
  whichimage=n;
  document.images.slide.src=imageholder[whichimage].src
  document.getElementById("textslide").innerText=slidetext[whichimage];
  document.getElementById("tu1").src=slidesanjiaoimages[0];
  document.getElementById("tu2").src=slidesanjiaoimages[0];
  document.getElementById("tu3").src=slidesanjiaoimages[0];
  document.getElementById("tu4").src=slidesanjiaoimages[0];
  document.getElementById("tu5").src=slidesanjiaoimages[0];
  document.getElementById(slidesanjiaoimagesname[whichimage]).src=slidesanjiaoimages[1];
}