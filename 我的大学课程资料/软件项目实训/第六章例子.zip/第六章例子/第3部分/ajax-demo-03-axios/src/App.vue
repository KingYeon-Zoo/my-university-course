<template>
  <div id="app">
    <button @click="startRequest">测试异步通信</button>
    <br><br>
    <div id="target">{{msg}}</div>
  </div>
</template>

<script>
import axios from 'axios'
axios.defaults.baseURL = 'http://demo-api.geekfun.website';

export default {
      data() {
        return {msg: ''}
      },
      methods: {
        startRequest() {
          axios
            .get('/vue/00/00.aspx')
            .then(response => this.msg = response.data)
        }
      }
}
</script>
