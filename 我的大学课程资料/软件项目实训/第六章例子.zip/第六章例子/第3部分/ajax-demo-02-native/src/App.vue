<template>
  <div id="app">
    <button @click="startRequest">测试异步通信</button>
    <br><br>
    <div id="target">{{msg}}</div>
  </div>
</template>

<script>
export default {
      data() {
        return {msg: ''}
      },
      methods: {
        startRequest() {
          let xmlHttp = new XMLHttpRequest();
          xmlHttp.open("GET","http://demo-api.geekfun.website/vue/00/00.aspx",true);
          xmlHttp.onreadystatechange = () => {
            if(xmlHttp.readyState == 4 && xmlHttp.status == 200)
              this.msg = xmlHttp.responseText;
          }
          xmlHttp.send(null);
        }
      }
}
</script>
