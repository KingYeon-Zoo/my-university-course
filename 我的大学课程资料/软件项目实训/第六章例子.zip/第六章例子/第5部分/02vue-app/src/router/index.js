import Vue from 'vue';
import VueRouter from 'vue-router';
Vue.use(VueRouter);

const routes = [
  {
    path: '/',
    name: 'Home',
    component: () => import('../views/home.vue'),
  },
  {
    path: '/product',
    name: 'Product',
    component: () => import('../views/product.vue'),
  },
  {
    path: '/article',
    name: 'Article',
    component: () => import('../views/article.vue'),
  },
  {
    path: '/contact',
    name: 'Contact',
    component: () => import('../views/contact.vue'),
  }
];

const router = new VueRouter({
  routes
});

export default router;
