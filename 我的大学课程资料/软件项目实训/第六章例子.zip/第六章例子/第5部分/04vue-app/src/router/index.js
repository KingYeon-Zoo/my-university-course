import Vue from 'vue';
import VueRouter from 'vue-router';
Vue.use(VueRouter);

const routes = [
  {
    path: '/',
    name: 'Home',
    component: () => import('../views/home.vue'),
  },
  {
    path: '/product/:page?/:tag?',
    name: 'Product',
    component: () => import('../views/product.vue'),
  },
  {
    path: '/product/:id', // 动态路径参数 以冒号开头
    name: 'ProductDetails',
    component: () => import('../views/product-details.vue'),
  },
  {
    path: '/article',
    name: 'Article',
    component: () => import('../views/article.vue'),
  },
  {
    path: '/contact',
    name: 'Contact',
    component: () => import('../views/contact.vue'),
  }
];

const router = new VueRouter({
  routes
});

export default router;
