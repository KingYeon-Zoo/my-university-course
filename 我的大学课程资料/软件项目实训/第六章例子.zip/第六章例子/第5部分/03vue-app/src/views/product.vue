<template>
  <section>
    <div class="container">
      <p class="description">这是“产品”页面</p>
      <div>
        <router-link v-bind:to="{name: 'ProductDetails', params: {id: 1}}">1号产品</router-link>
      </div><div>
        <router-link v-bind:to="{name: 'ProductDetails', params: {id: 2}}">2号产品</router-link>
      </div>
    </div>
  </section>
</template>

<script>
export default {
}
</script>

<style scoped>
.container div {
  text-align: center;
  line-height: 1.5;
  margin-top: 10px;
  font-size: 28px;
}
</style>