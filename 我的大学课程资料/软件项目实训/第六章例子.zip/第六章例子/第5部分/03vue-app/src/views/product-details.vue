<template>
  <section>
    <div class="container">
      <p class="description">
        这是“{{$route.params.id}} 号产品”页面
      </p>
    </div>
  </section>
</template>