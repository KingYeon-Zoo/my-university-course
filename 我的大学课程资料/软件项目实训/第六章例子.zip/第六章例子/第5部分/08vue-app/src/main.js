import Vue from 'vue'
import App from './App.vue'
import router from './router';

import '@/assets/style.css'

Vue.config.productionTip = false

router.beforeEach(function(to, from, next) {
  let isLogin = false //用户登录状态
  // 根据路由元信息判断
  if (to.matched.some(record => record.meta.requireLogin)) {
    if (isLogin) {
      next() // 直接进入路由显示内容
    } else {
      next({ name: 'Login' }) // 进入登录页面
    }
  } else {
    next() // 确保一定要调用 next()
  }
})

new Vue({
  router,
  render: h => h(App),
}).$mount('#app')
