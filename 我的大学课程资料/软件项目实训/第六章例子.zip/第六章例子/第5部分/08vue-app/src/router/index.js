import Vue from 'vue';
import VueRouter from 'vue-router';
Vue.use(VueRouter);

const routes = [
  {
    path: '/',
    name: 'Home',
    component: () => import('../views/home.vue'),
  },
  {
    path: '/product',
    name: 'Product',
    component: () => import('../views/product.vue'),
    meta: {
      requireLogin: true
    }
  },
  {
    path: '/product/:id', // 动态路径参数 以冒号开头
    name: 'ProductDetails',
    component: () => import('../views/product-details.vue'),
  },
  {
    path: '/article',
    name: 'Article',
    component: () => import('../views/article.vue'),
  },
  {
    path: '/contact',
    name: 'Contact',
    component: () => import('../views/contact.vue'),
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('../views/login.vue'),
  },
  {
    path: '*',
    name: 'Page404',
    component: () => import('../views/page404.vue'),
  }
];

const router = new VueRouter({
  routes
});

export default router;
