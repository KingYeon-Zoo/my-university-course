<template>
  <div id="app">
    <vue-header />
    <router-view></router-view>
    <vue-footer />
  </div>
</template>

<script>
import VueHeader from './components/header'
import VueFooter from './components/footer'

export default {
  name: 'app',
  components: {
    VueHeader,
    VueFooter
  },
  data() {
    return {
    };
  }
}
</script>

<style>
</style>
