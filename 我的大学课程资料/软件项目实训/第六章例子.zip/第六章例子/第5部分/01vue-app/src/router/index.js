import Vue from 'vue';
import VueRouter from 'vue-router';
Vue.use(VueRouter);

const routes = [
  {
    path: '/',
    component: () => import('../views/home.vue'),
  },
  {
    path: '/product',
    component: () => import('../views/product.vue'),
  },
  {
    path: '/article',
    component: () => import('../views/article.vue'),
  },
  {
    path: '/contact',
    component: () => import('../views/contact.vue'),
  }
];

const router = new VueRouter({
  routes
});

export default router;
