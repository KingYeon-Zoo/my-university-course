<template>
  <div id="app">
    <vue-header />
    <div>
      <router-view></router-view>
      <div class="container home-view">
        <router-view name="a"></router-view>
        <router-view name="b"></router-view>
      </div>
    </div>
    <vue-footer />
  </div>
</template>

<script>
import VueHeader from './components/header'
import VueFooter from './components/footer'

export default {
  name: 'app',
  components: {
    VueHeader,
    VueFooter
  },
  data() {
    return {
    };
  }
}
</script>

<style>
.home-view > div {
  display: inline-block;
  border: 1px solid #000;
  height: 180px;
  font-size: 18px;
  text-align: center;
  margin-top: 20px;
  border-radius: 10px;
}
</style>
