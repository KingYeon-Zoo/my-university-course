import Vue from 'vue'
import App from './App.vue'
import router from './router';

import '@/assets/style.css'

Vue.config.productionTip = false

// 注册全局前置守卫
router.beforeEach(function(to, from, next) {
  let isLogin = false //默认用户是未登录状态
  // 例如，从首页进入产品页面，需要判断是否是登录状态
  console.log(to.matched)
  if (
    to.matched.some(item => {
      console.log(item)
      return item.meta.require_login;
    })
  ) {
    // 需要登录
    if (isLogin) { //判断用户登录是否是登录状态
      console.log('登录状态')
      // 是登录状态，直接进入路由显示内容
      next()
    } else {
      // 不是登录状态，不能进入下一个路由，直接弹框提示用户让登录
      console.log('未登录状态，弹框登录')
      alert('需要登陆')
      return
    }
  } else {
    next()
  }
  console.log('进入路由成功')
})

new Vue({
  router,
  render: h => h(App),
}).$mount('#app')
