<template>
  <section>
    <div class="container">
      <p class="description">
        这是“产品”页面 <br>
        产品id为：{{id}}
      </p>
      <button @click="change">修改id为2</button>
    </div>
  </section>
</template>

<script>
export default {
  name: 'Product',
  data() {
    return {
      id: '' //产品id
    }
  },
  watch: {
    $route(to, from) {
      console.log(to)
      console.log(from)
      this.id = to.params.id
    }
  },
  created() {
    this.id = this.$route.params.id
  },
  methods: {
    change() {
      this.$router.push({
        name: 'Product',
        params: {
          id: 2
        }
      })
    }
  }
}
</script>

<style>
</style>