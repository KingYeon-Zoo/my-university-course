<template>
  <section>
    <div class="container">
      <p class="description">
        这是“文章”页面 <br>
        页码：{{obj.page}}，标签：{{obj.tag}}
      </p>

      <button @click="showDeatil">显示详情信息</button>
      <router-view></router-view>
    </div>
  </section>
</template>

<script>
export default {
  name: 'Article',
  data() {
    return {
      obj: {}
    }
  },
  created() {
    // this.obj = this.$route.params
    this.obj = this.$route.query
  },
  methods: {
    showDeatil() {
      this.$router.push({
        path: '/article/detail/1'
      })
    }
  }
}
</script>

<style>
</style>