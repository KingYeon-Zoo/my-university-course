<template>
  <div class="main">
    Main
  </div>
</template>
<script>
export default {
  name: "Main"
}
</script>
<style scoped>
.main {
  margin-left: 50px;
  width: 85%;
}
</style>