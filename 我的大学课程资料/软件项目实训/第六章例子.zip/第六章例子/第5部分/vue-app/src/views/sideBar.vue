<template>
  <div class="sidebar">
    SideBar
  </div>
</template>
<script>
export default {
  name: "SideBar"
}
</script>
<style scoped>
.sidebar {
  width: 100px;
}
</style>