import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter);

import Home from '../views/home.vue'
import Product from '../views/product.vue'
import Article from '../views/article.vue'
import Contact from '../views/contact.vue'

import articleDetail from '../views/articleDetail.vue'

import SideBar from '../views/sideBar.vue'
import Main from '../views/main.vue'

import Page404 from '../views/page404.vue'

const routes = [
  {
    path: '/',
    name: 'Home',
    // component: Home
    components: {
      default: Home,
      a: SideBar,
      b: Main
    },
    meta: {
      require_login: false
    }
  },
  {
    path: '/product/:id',
    name: 'Product',
    component: Product,
    meta: {
      require_login: true
    }
  },
  // {
  //   path: '/article/:page/:tag',
  //   name: 'Article',
  //   component: Article
  // },
  {
    path: '/article',
    name: 'Article',
    component: Article,
    children: [
      {
        path: '/article/detail/:id',
        component: articleDetail
      }
    ],
    alias: '/articles',
    meta: {
      require_login: true
    }
  },
  {
    path: '/contact',
    name: 'Contact',
    component: Contact,
    meta: {
      require_login: false
    }
  },
  {
    path: '*',
    name: 'Page404',
    component: Page404
  }
];

const router = new VueRouter({
  mode: 'history',
  routes
});

export default router;
