<template>
  <section>
    <div class="container">
      <p class="description">这是“登录页”</p>
    </div>
  </section>
</template>

<script>
export default { }
</script>

<style>
</style>