import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state:{
    products:[]  
  },
  getters:{
      products(state){
        return state.products;
      }
  },
  mutations: {
    addToCart(state, name){
      if(!state.products.includes(name))
        state.products.push(name);
    },
    checkOut(state){
        //……这里省略下订单的逻辑……
        state.products=[];
    }
  }
})
