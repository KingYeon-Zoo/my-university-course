<template>
  <div id="app">
    <!-- 固定在顶部 -->
    <div class="fixed-top">
      <div class="container">
        <!-- 添加待办事项 -->
        <form class="input-form" action="">
          <label class="form-label" for="content">Todo</label>
          <input type="text">
          <button type="submit" class="btn-regular">Add</button>
        </form>
        <!-- 筛选项 -->
      </div>
    </div>
    <!-- 任务列表 -->
    <!-- 弹框 -->
  </div>
</template>

<script>
export default {
  name: 'App',
  data() {
    return { isEditing: true }
  }
}
</script>

<style lang="scss">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  color: #212529;
  margin-top: 80px;
}
*, ::after, ::before {
  box-sizing: border-box;
  padding: 0;
  margin: 0;
}
.container {
  width: 100%;
  max-width: 720px;
  padding: 0 15px;
  margin: 0 auto;
}
.btn-regular {
  padding: .25rem .5rem;
  color: #fff;
  background-color: #007bff;
  border: 1px solid #007bff;
  border-radius: 0;
  font-size: .875rem;
  line-height: 1.5;
}
button {
  cursor: pointer;
}
.fixed-top {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  // 添加待办事项
  .input-form {
    display: flex;
    width: 100%;
    margin-top: 15px;
    .form-label {
      display: flex;
      font-size: 1rem;
      border: 1px solid #979797;
      border-right: none;
      background: #faf9f9;
      line-height: 1.5;
      padding: .25rem .5rem;
    }
    input[type="text"] {
      padding: 2px 4px;
      font-size: 1rem;
      flex-grow: 1;
    }
  }
}
</style>