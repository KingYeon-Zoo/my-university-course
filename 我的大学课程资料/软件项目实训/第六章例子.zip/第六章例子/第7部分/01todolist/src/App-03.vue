<template>
  <div id="app">
    <!-- 固定在顶部 -->
    <div class="fixed-top">
      <div class="container">
        <!-- 添加待办事项 -->
        <form class="input-form" action="">
          <label class="form-label" for="content">Todo</label>
          <input type="text">
          <button type="submit" class="btn-regular">Add</button>
        </form>
        <!-- 筛选项 -->
        <div class="status-boxes">
          <label>
            <input type="checkbox">
            <span class="status-name">Todo</span>
            <span class="badge badge-light">0</span>
          </label>
          <label>
            <input type="checkbox">
            <span class="status-name">In Progress</span>
            <span class="badge badge-warning">0</span>
          </label>
          <label>
            <input type="checkbox">
            <span class="status-name">Done</span>
            <span class="badge badge-success">0</span>
          </label>
        </div>
      </div>
    </div>
  
    <div class="container">
      <!-- 任务列表 -->
      <div class="main-content">
        <div class="list-group">
          <div class="list-group-item">
            <div class="todo-move">
              <font-awesome-icon icon="ellipsis-v" size="xs"/>
            </div>
            <div class="pointer todo-status todo-status-light"></div>
            <div class="todo-text">测试</div>
            <div>
              <font-awesome-icon icon="edit" size="xs" class="pointer"/>
            </div>
            <div>
              <font-awesome-icon icon="times" size="xs" class="pointer"/>
            </div>
          </div>
          <div class="list-group-item">
            <div class="todo-move">
              <font-awesome-icon icon="ellipsis-v" size="xs"/>
            </div>
            <div class="pointer todo-status todo-status-warning"></div>
            <div class="todo-text">测试</div>
            <div>
              <font-awesome-icon icon="edit" size="xs" class="pointer"/>
            </div>
            <div>
              <font-awesome-icon icon="times" size="xs" class="pointer"/>
            </div>
          </div>
          <div class="list-group-item">
            <div class="todo-move">
              <font-awesome-icon icon="ellipsis-v" size="xs"/>
            </div>
            <div class="pointer todo-status todo-status-success"></div>
            <div class="todo-text">测试</div>
            <div>
              <font-awesome-icon icon="edit" size="xs" class="pointer"/>
            </div>
            <div>
              <font-awesome-icon icon="times" size="xs" class="pointer"/>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- 弹框 -->
  </div>
</template>

<script>
export default {
  name: 'App',
  data() {
    return { isEditing: true }
  }
}
</script>

<style lang="scss">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  color: #212529;
  margin-top: 80px;
}
*, ::after, ::before {
  box-sizing: border-box;
  padding: 0;
  margin: 0;
}
.container {
  width: 100%;
  max-width: 720px;
  padding: 0 15px;
  margin: 0 auto;
}
.btn-regular {
  padding: .25rem .5rem;
  color: #fff;
  background-color: #007bff;
  border: 1px solid #007bff;
  border-radius: 0;
  font-size: .875rem;
  line-height: 1.5;
}
button {
  cursor: pointer;
}
.fixed-top {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  // 添加待办事项
  .input-form {
    display: flex;
    width: 100%;
    margin-top: 15px;
    .form-label {
      display: flex;
      font-size: 1rem;
      border: 1px solid #979797;
      border-right: none;
      background: #faf9f9;
      line-height: 1.5;
      padding: .25rem .5rem;
    }
    input[type="text"] {
      padding: 2px 4px;
      font-size: 1rem;
      flex-grow: 1;
    }
  }

  // 筛选项
  .status-boxes {
    display: flex;
    justify-content: space-between;
    margin-top: 10px;

    label {
      display: flex;
      align-items: center;
    }

    .status-name {
      margin: 0 5px;
    }

    .badge {
      display: inline-block;
      padding: 2px 5px;
      text-align: center;
      border-radius: .25rem;
      font-size: 75%;
      white-space: nowrap;
      font-weight: bold;
      vertical-align: baseline;

      &-light {
        background-color: #fff;
        border: 1px solid #000;
      }

      &-warning {
        background-color: #ffc107;
        border: 1px solid #ffc107;
      }

      &-success {
        color: #fff;
        background-color: #28a745;
        border: 1px solid #28a745;
      }
    }
  }
}



// todo列表
.main-content {
  padding-top: 2rem;

  .list-group {
    border-left: 1px solid #979797;
    border-right: 1px solid #979797;

    .list-group-item:first-child {
      border-top: 1px solid #979797;
    }

    .list-group-item {
      border-bottom: 1px solid #979797;
      padding: 0.25rem 0.5rem;
      background-color: #faf9f9;  
      display: flex;
      align-items: center;

      div {
        padding: 0.25rem;
      }

      .pointer {
        cursor: pointer;
      }

      .todo-move {
        cursor: move;
      }

      .todo-status {
        width: 20px;
        height: 20px;
        display: inline-block;
        border-radius: 50%;
        -webkit-border-radius: 50%;
        -moz-border-radius: 50%;

        &-light {
          border: 1px solid #000;
          background-color: #fff;
        }

        &-warning {
          border: 1px solid #ffc107;
          background-color: #ffc107;
        }

        &-success {
          border: 1px solid #28a745;
          background-color: #28a745;
        }
      }

      .todo-text {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        flex-grow: 1;
        text-align: left;
      }
    }
  }
}
</style>