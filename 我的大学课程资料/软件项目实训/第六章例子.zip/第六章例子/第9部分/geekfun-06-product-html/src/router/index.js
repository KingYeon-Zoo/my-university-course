import Vue from 'vue'
import VueRouter from 'vue-router'

import UnderConstruction from '../views/UnderConstruction.vue'
import PageNotFound from '../views/PageNotFound.vue'
import Products from '../views/Products.vue'
import ProductDetail from '../views/ProductDetail.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: UnderConstruction
  },
  {
    path: '/products',
    name: 'Products',
    component: Products
  },
  {
    path: '/products/:productId',
    name: 'ProductDetail',
    component: ProductDetail
  },
  {
    path: '/orders/:orderId',
    name: 'OrderDetail',
    component: UnderConstruction
  },
  {
    path: '/orders',
    name: 'Orders',
    component: UnderConstruction
  },
  {
    path: '/about',
    name: 'About',
    component: UnderConstruction
  },
  {
    path: '/404',
    name: '404',
    component: PageNotFound
  },
  {
    path: '*',
    redirect: '/404'
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
