<template>
  <div class="container">
    <div class="row gy-4">
      <div class="col-12 col-md-4">
        <img 
           src="../assets/images/1.png"
          class="img-fluid img-thumbnail"
        >
      </div>
      <div class="col-12 col-md-4 d-flex flex-column">
        <h3 class="mb-3 fw-bold">产品名称</h3>
        <p class="mb-3">价格：9.99元</p>
        <p class="info">产品介绍</p>
        <div class="d-grid mt-auto">
          <button 
            class="btn btn-outline-secondary btn-lg"
          >
            加入购物车
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

