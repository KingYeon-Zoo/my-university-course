<template>
  <div>
    <h2>没有找到页面……</h2>
  </div>
</template>

<style>
h2{
  text-align:center;
}
</style>
