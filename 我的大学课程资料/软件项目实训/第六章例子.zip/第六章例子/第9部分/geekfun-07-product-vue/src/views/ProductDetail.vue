<template>
  <div class="container">
    <div v-if="product" class="row gy-4">
      <div class="col-12 col-md-4">
        <img 
          :src="product.src"
          class="img-fluid img-thumbnail"
        >
      </div>
      <div class="col-12 col-md-4 d-flex flex-column">
        <h3 class="mb-3 fw-bold">{{product.name}}</h3>
        <p class="mb-3">价格：{{product.price}}元</p>
        <p class="info">{{product.description}}</p>
        <div class="d-grid mt-auto">
          <button 
            class="btn btn-outline-secondary btn-lg"
          >
            加入购物车
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import shoppingApi from '../assets/js/shoppingApi'

export default {
  data() {
    return {
      product: null
    }
  },
  mounted(){
    shoppingApi.getProduct(
      Number(this.$route.params.productId),       
      // 成功操作
      (productFromServer) => {
        this.product = productFromServer;
      },
      // 失败操作
      () => {
        console.log("error");
      }
    )
  }
}
</script>

