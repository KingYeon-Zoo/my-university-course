<template>
  <div class="container">
    <div class="row">
      <div class="col-md-10">
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>产品</th>
              <th>价格</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>泊松分布马克杯</td>
              <td>99.99 元</td>
            </tr>
          </tbody>
        </table>
        <ul class="list-unstyled lh-lg">
          <li>订单编号：#1234567</li>
          <li>下单时间：2021/5/7下午4:30:55</li>
          <li>订单状态：
            <span 
              class="fw-bold fs-5 text-danger"
            >
              待支付
            </span>
          </li>
        </ul>
        <p class="fs-4">
          <span class="fw-bold">
            合计：
          </span> 
          99.99 元
        </p>
        <button 
          class="btn btn-outline-success btn-lg px-4"
        >
          去支付
        </button>
      </div>
    </div>
  </div>
</template>
