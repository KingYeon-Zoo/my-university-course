<template>
  <div>
    <h2>正在建设中……</h2>
  </div>
</template>

<style>
h2{
  text-align:center;
}
</style>
