import productCatalog from './productCatalog'

export default {
  //获取所有产品目录
  getProductCatalog(successCallback, errorCallback){
    //模拟请求远程API，耗时1~2秒的随机时长
    const timeout = Math.random() * 1000 + 1000;
    //以80%成功概率，模拟从远程获取数据，
    const success= Math.random() < 0.8;
    setTimeout(() => {
      if(success) {
        //调用成功的回调函数
        successCallback(productCatalog);
      }
      else {
        //调用失败的回调函数
        errorCallback();
      }
    }, timeout);
  }
}