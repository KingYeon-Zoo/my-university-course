<template>
  <div id="app">
    <div id="nav" class="p-5 text-center">
      <span>
        购物车<strong class="badge rounded-pill bg-primary">
          {{cartCount}}
          </strong>
      </span> | 
      <router-link class="fw-bold" to="/">首页</router-link> |
      <router-link class="fw-bold" to="/products">产品</router-link> |
      <router-link class="fw-bold" to="/orders">订单</router-link> |
      <router-link class="fw-bold" to="/about">关于我们</router-link>
    </div>
    <router-view/>
    <vue-cart />
  </div>
</template>

<script>
import VueCart from './components/Cart'


export default {
  components: {
    VueCart
  },
  computed: {
    cartCount(){
      return this.$store.state.cart.products.length;
    }
  }
}

</script>



<style>
#nav a.router-link-exact-active {
  color: #42b983 !important;
}
</style>
