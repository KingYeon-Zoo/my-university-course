import Vue from 'vue'
import Vuex from 'vuex'

import storage from '../assets/js/localStorage'
import loadingModule from './loading'
import cartModule from './cart'

Vue.use(Vuex)

let store = new Vuex.Store({
  modules:{
    cart: cartModule, 
    loading: loadingModule
  }
});

store.watch(
  state => state.cart.products,
  value => storage.cart.save(value)
);

export default store

