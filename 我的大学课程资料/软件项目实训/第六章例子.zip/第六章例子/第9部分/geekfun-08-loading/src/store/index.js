import Vue from 'vue'
import Vuex from 'vuex'

import loadingModule from './loading'

Vue.use(Vuex)

export default new Vuex.Store({
  modules:{
    loading: loadingModule
  }
})
