// 购物车
class cart {
  static fetch() {
    return JSON.parse(localStorage.getItem('cart') || '[]')
  }

  static save(cart) {
    localStorage.setItem('cart', JSON.stringify(cart))
  }
}

export default{
  cart
}