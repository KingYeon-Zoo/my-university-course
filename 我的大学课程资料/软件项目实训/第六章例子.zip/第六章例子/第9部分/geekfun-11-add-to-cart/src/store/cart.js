import Storage from '../assets/js/localStorage'

export default {
    namespaced: true,
    state: {
      products: Storage.cart.fetch(),  
    },
    getters:{
      totalPrice: (state) => 
        state.products.reduce((a, b) => (a + Number(b.price)), 0) 
    },
    mutations: {
      add(state, product) {
        if(!state.products.find(_=>
          _.productId == product.productId))
          state.products.push(product);
      }
    }
  };
