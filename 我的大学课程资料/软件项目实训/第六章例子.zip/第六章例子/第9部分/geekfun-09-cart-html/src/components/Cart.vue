<template>
  <div 
      id="cart" 
      class="
        border 
        border-2 
        border-secondary
        rounded-start 
        border-end-0 
        bg-white 
        position-fixed 
        end-0 
        p-3 
        pe-0"
      style="top: 450px" 
    >
    <div class="shandow bg-light p-3 lh-lg">
        <div>购物车中暂无商品……</div>
    </div>
    
    <div 
      class="d-flex align-items-center mt-3 me-3" 
    >
      <button 
        class="btn border-2 btn-primary btn-sm"
      >
        确认下单
      </button>
      <div class="ms-auto">
        总价：99.99 元
      </div> 
    </div>
  </div>
</template>

<style>
  #cart{
    z-index:2000; 
    width:300px;
  }
</style>
