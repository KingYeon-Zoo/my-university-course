<template>
  <div class="container">
    <div class="row g-2 g-md-3">
      <div 
        class="col-6 col-md-4 col-lg-3 col-xxl-2"
      >
        <div class="px-3">
          <img src="../assets/images/1.png" class="img-fluid">
        </div>
        <div class="text-center py-3 px-md-3">
          <h6 class="mb-3">产品名称</h6>
          <div class="d-flex justify-content-evenly">
            <router-link 
              to="/products/1" 
              class="btn btn-outline-secondary btn-sm"
            >
              查看详情
            </router-link>
            <button 
              class="btn btn-outline-secondary btn-sm"
            >
              加入购物车
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>