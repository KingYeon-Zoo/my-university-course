import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

//引入Bootstrap
//cnpm install bootstrap
import "bootstrap/dist/js/bootstrap.bundle";
import "bootstrap/dist/css/bootstrap.min.css";

Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
