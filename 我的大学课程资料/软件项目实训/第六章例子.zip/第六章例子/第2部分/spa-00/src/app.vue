<template>
  <div>
    <vue-header />
    <vue-home />
    <vue-product />
    <vue-article />
    <vue-contact />
    <vue-footer />
  </div>
</template>

<script>
import VueHeader from './components/header'
import VueHome from './components/home'
import VueProduct from './components/product'
import VueArticle from './components/article'
import VueContact from './components/contact'
import VueFooter from './components/footer'

export default {
  components: {
    VueHeader,
    VueHome,
    VueProduct,
    VueArticle,
    VueContact,
    VueFooter
  }
}
</script>

<style>
</style>
