<template>
  <section>
    <div class="container">
      <p class="description">这是“产品”页面</p>
    </div>
  </section>
</template>

<script>
export default {
}
</script>

<style>
</style>