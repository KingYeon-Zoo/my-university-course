<template>
  <header>
    <div class="container">
      <nav class="header-wrap">
        <img src="../assets/logo.png" alt="logo">
        <ul>
          <li v-for="item in navList" :key="item.name" >
            {{item.name}}
          </li>
        </ul>
      </nav>
    </div>
  </header>
</template>

<script>
export default {
  data() {
    return {
      navList: [
        {name: '首页'}, {name: '产品'}, {name: '文章'},{name: '联系我们'}
      ]
    }
  }
}
</script>

<style>
</style>