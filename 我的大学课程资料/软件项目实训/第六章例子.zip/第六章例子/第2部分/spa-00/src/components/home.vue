<template>
  <section>
    <div class="container">
      <p class="description">这是“首页”</p>
    </div>
  </section>
</template>

<script>
export default {
}
</script>

<style>
</style>