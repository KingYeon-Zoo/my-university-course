@echo off
set xv_path=E:\\Xilinx\\Vivado\\2017.2\\bin
call %xv_path%/xelab  -wto 9d80c5dfb93e42f18bacd05f40544e87 -m64 --debug typical --relax --mt 2 -L fifo_generator_v13_1_4 -L xil_defaultlib -L unisims_ver -L unimacro_ver -L secureip -L xpm --snapshot uart_top_tb_behav xil_defaultlib.uart_top_tb xil_defaultlib.glbl -log elaborate.log
if "%errorlevel%"=="0" goto SUCCESS
if "%errorlevel%"=="1" goto END
:END
exit 1
:SUCCESS
exit 0
