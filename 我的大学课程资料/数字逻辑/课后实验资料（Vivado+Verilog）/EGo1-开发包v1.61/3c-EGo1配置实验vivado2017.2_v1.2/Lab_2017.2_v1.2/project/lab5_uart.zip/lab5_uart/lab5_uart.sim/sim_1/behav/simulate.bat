@echo off
set xv_path=E:\\Xilinx\\Vivado\\2017.2\\bin
call %xv_path%/xsim uart_top_tb_behav -key {Behavioral:sim_1:Functional:uart_top_tb} -tclbatch uart_top_tb.tcl -log simulate.log
if "%errorlevel%"=="0" goto SUCCESS
if "%errorlevel%"=="1" goto END
:END
exit 1
:SUCCESS
exit 0
