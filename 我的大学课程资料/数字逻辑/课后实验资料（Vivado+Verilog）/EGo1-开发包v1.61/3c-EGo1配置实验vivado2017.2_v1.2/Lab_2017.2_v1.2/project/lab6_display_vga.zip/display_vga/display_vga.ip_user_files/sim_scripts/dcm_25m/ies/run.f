-makelib ies/xil_defaultlib -sv \
  "D:/Xilinx/Vivado/2017.2/data/ip/xpm/xpm_cdc/hdl/xpm_cdc.sv" \
-endlib
-makelib ies/xpm \
  "D:/Xilinx/Vivado/2017.2/data/ip/xpm/xpm_VCOMP.vhd" \
-endlib
-makelib ies/xil_defaultlib \
  "../../../../display_vga.srcs/sources_1/ip/dcm_25m/dcm_25m_clk_wiz.v" \
  "../../../../display_vga.srcs/sources_1/ip/dcm_25m/dcm_25m.v" \
-endlib
-makelib ies/xil_defaultlib \
  glbl.v
-endlib

